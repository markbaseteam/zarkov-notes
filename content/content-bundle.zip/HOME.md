---
dg-publish: true
dg-home: true
---
```dataview
TABLE file.folder AS "Pasta", file.tags AS "Categoria", file.mtime AS "Modificado"
where dg-publish
SORT file.folder asc
```

