---
dg-publish: true
---
**CFG Scale: `1-7 (+0.5)`** Irá avançando de 0.5 a 0.5…

**Steps:** `10-35 [5]` Isso irá fazer com que avance a cada 5 steps até chegar ao 35

**Sampler:** `Euler a, DMP++ SDA Karras, DPM 2M Karras`

**Different prompts**: Positive prom actpt - highly detailed RAW color Photo of (gorgeous stunning naked woman), (highly detailed pussy, realistic pussy, shaved pussy, realistic clitoris, medium boobs, realistic nipples, detailed nipples), highly detailed legs, big lips, (skin pores), sharp body, highly **detailed body**, highly detailed face, perfect lighting, shadows, sharp focus, 8k high definition, insanely detailed, intricate, masterpiece, highest quality, white pale skin,(cropped head:1.5)

-   Escolha uma palavra que gostaria de modificar, coloque essa palavra por primeiro em Prompt S/R, Então em seguida, usando vírgulas você coloca a palavra que quiser, exemplo: `detailed body, intricate body, intricate face, detailed face, pale body`