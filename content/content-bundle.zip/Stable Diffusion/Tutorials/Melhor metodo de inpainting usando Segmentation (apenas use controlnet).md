---
tag: StableDiffusion
link: https://www.notion.so/Melhor-metodo-de-inpainting-usando-Segmentation-apenas-use-controlnet-91737aa8783d4f7c82cfb137ff4e5d06
notionID: 91737aa8-783d-4f7c-82cf-b137ff4e5d06
dg-publish: true
---
![[Pasted image 20230620235529.png]]